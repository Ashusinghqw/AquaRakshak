# AquaRakshak
Vanilla HTML/CSS/JS + Chart.js frontend, Node/Express backend, Supabase PostgreSQL.

## Connect Supabase (about 2 minutes)
1. Create a project at supabase.com.
2. SQL Editor: run `database/schema.sql`, then `database/seed.sql` (it prints the meter id).
3. Project Settings > API: copy the Project URL and the **service_role** key.
4. `cd backend && cp .env.example .env`, paste both values. Never put this key in frontend code or commit `.env`.
5. `npm install && npm run check-db` (all four tables should say ok), then `npm start` and open http://localhost:3000

Save a reading (replace METER_ID):
`curl -X POST localhost:3000/api/readings -H "content-type: application/json" -d '{"meter_id":"METER_ID","previous_reading":100,"current_reading":260,"days":10}'`
Then press "Load saved data" on the dashboard.

## Alert rule
Alert when average daily usage > 125% of the meter's `expected_daily_usage`. Rule-based, not AI.

## Before deploying
Replace `https://example.com` in `index.html`, `robots.txt`, `sitemap.xml`.
