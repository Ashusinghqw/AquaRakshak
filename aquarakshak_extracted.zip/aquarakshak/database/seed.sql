-- Run after schema.sql. Creates one demo meter; copy its id for POST /api/readings.
insert into meters(name,expected_daily_usage,unit) values('Main building meter',11.5,'kL') returning id;
