require('dotenv').config();
const express=require('express'),helmet=require('helmet'),cors=require('cors'),rate=require('express-rate-limit'),path=require('path');
const {createClient}=require('@supabase/supabase-js');
let db=null;const U=process.env.SUPABASE_URL,K=process.env.SUPABASE_SERVICE_ROLE_KEY;
if(U&&K&&!/YOUR-PROJECT/.test(U)&&K!=='server-side-only'){try{db=createClient(U,K)}catch(e){console.warn('Supabase not connected:',e.message)}}else console.log('Supabase not configured: running without database (calculator, report and demo still work).');
const app=express();app.use(helmet({contentSecurityPolicy:false}));app.use(cors({origin:process.env.ALLOWED_ORIGIN||false}));app.use(express.json({limit:'20kb'}));
app.use('/api',rate({windowMs:60000,max:60}));
const need=(q,res,next)=>db?next():res.status(503).json({error:'Database not configured'});
const wrap=fn=>async(req,res)=>{try{await fn(req,res)}catch(e){console.error(e.message);res.status(500).json({error:'Server error'})}};
const str=(v,max)=>String(v??'').replace(/[<>]/g,'').trim().slice(0,max);
const THRESHOLD=1.25; // alert when average daily usage > 125% of the meter's expected daily usage
app.post('/api/contact',need,wrap(async(req,res)=>{const b=req.body,d={full_name:str(b.full_name,100),phone_number:str(b.phone_number,25),email:str(b.email,120),booking_reason:str(b.booking_reason,500),additional_message:str(b.additional_message,1000)||null};
if(d.full_name.length<2||d.booking_reason.length<10||!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(d.email)||d.phone_number.replace(/\D/g,'').length<10)return res.status(400).json({error:'Invalid input'});
const {error}=await db.from('contact_requests').insert(d);if(error)throw error;res.status(201).json({ok:true})}));
app.post('/api/readings',need,wrap(async(req,res)=>{const {meter_id,previous_reading:p,current_reading:c,days=1}=req.body,d=Number(days);
if(!meter_id||![p,c].every(n=>Number.isFinite(+n)&&+n>=0)||+c<+p||!Number.isInteger(d)||d<1)return res.status(400).json({error:'Invalid reading'});
const cons=+c-+p,{data:r,error}=await db.from('readings').insert({meter_id,previous_reading:+p,current_reading:+c,consumption:cons}).select().single();if(error)throw error;
const {data:m}=await db.from('meters').select('expected_daily_usage').eq('id',meter_id).single();let alert=null;
if(m?.expected_daily_usage&&cons/d>m.expected_daily_usage*THRESHOLD){alert={reading_id:r.id,alert_type:'usage_above_baseline',message:`Average ${(cons/d).toFixed(2)} kL/day exceeds 125% of expected ${m.expected_daily_usage} kL/day. Inspect for possible water loss.`};await db.from('alerts').insert(alert)}
res.status(201).json({reading:r,alert})}));
app.get('/api/readings',need,wrap(async(_q,res)=>{const {data,error}=await db.from('readings').select('*').order('recorded_at',{ascending:false}).limit(60);if(error)throw error;res.json(data)}));
app.get('/api/alerts',need,wrap(async(_q,res)=>{const {data,error}=await db.from('alerts').select('*').order('created_at',{ascending:false}).limit(50);if(error)throw error;res.json(data)}));
app.patch('/api/alerts/:id',need,wrap(async(req,res)=>{const s=req.body.status;if(!['open','investigating','resolved'].includes(s))return res.status(400).json({error:'Invalid status'});const {data,error}=await db.from('alerts').update({status:s}).eq('id',req.params.id).select().single();if(error)throw error;res.json(data)}));
app.get('/api/analytics',need,wrap(async(_q,res)=>{const {data,error}=await db.from('readings').select('consumption');if(error)throw error;const t=data.reduce((a,r)=>a+ +r.consumption,0);res.json({readings:data.length,total_kl:t,average_kl:data.length?t/data.length:0})}));
app.use('/api',(_q,res)=>res.status(404).json({error:'Not found'}));
app.use(express.static(path.join(__dirname,'../frontend')));
const P=process.env.PORT||3000;
app.listen(P,()=>console.log(`AquaRakshak running at http://localhost:${P}`)).on('error',e=>{console.error(e.code==='EADDRINUSE'?`Port ${P} is busy. Try: PORT=3001 npm start`:e.message);process.exit(1)});
