// Usage: npm run check-db  (verifies .env + tables, prints the meter id to use)
require('dotenv').config();
const {createClient}=require('@supabase/supabase-js');
const {SUPABASE_URL:u,SUPABASE_SERVICE_ROLE_KEY:k}=process.env;
if(!u||!k){console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in backend/.env');process.exit(1)}
const db=createClient(u,k);
(async()=>{for(const t of ['meters','readings','alerts','contact_requests']){const {error}=await db.from(t).select('id').limit(1);console.log(error?`FAIL ${t}: ${error.message}`:`ok   ${t}`);if(error)process.exitCode=1}
const {data}=await db.from('meters').select('id,name').limit(1);console.log(data?.length?`Meter id: ${data[0].id}`:'No meter yet: run database/seed.sql')})();
